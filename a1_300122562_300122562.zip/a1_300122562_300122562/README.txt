Student name: Natasha Hussain
Student number: 300122562
Course Code: ITI 1121
Lab Section: A02

This archive contains 5 files of assignment 1, this is file (README.txt),
and the files CellValue.java, GameState.java, StudentInfo.java, TicTacToe.java,
TicTacToeGame.java

I worked alone on this assignment. 